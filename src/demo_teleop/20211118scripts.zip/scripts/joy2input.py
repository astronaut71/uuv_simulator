#!/usr/bin/env python


import rospy
#from std_msgs.msg import MultiArrayDimension
from std_msgs.msg import Int16
from sensor_msgs.msg import Joy

pub_cmd = rospy.Publisher('/to_modem', Int16, queue_size=1)
cmd = Int16()
cmd = 121

def send_cmd(j):

    global cmd
    up = j.buttons[13]
    down = j.buttons[14]
    surge = j.axes[4]
    yaw = j.axes [3]

    zvalue = up - down +1
    surgevalue = int(round(surge*4))  +4
    yawvalue = int(round(yaw*4))  +4

    int_p = zvalue*81 + surgevalue*9 + yawvalue

    p = Int16()
    p = int_p

#    p.layout.dim.append(MultiArrayDimension())
#    p.layout.dim[0].label = 'sending_cmd'
#    p.layout.dim[0].size = 1
#    p.layout.dim[0].stride = 3
#    p.layout.data_offset = 0
#    p.data = [zvalue,surgevalue,yawvalue]

    cmd = p

def read_joy():
    try:
        rospy.wait_for_message("/joy", Joy, timeout=1.9)
        rospy.Subscriber("/joy", Joy, send_cmd)

    except:
        rate.sleep()


if __name__ == '__main__':
    rospy.init_node('joy2input')
    rate = rospy.Rate(10)

    while not rospy.is_shutdown():
        last_cmd = cmd

        while True:

            now = rospy.get_time()
            while rospy.get_time() - now < 1: 
                rospy.Subscriber("/joy", Joy, send_cmd)
                rate.sleep()

            if  last_cmd != cmd or cmd<81 or cmd>162:
                pub_cmd.publish(cmd)
                rospy.loginfo(cmd)
                last_cmd = cmd 
            else:
                break


        read_joy()
        pub_cmd.publish(cmd)
        rospy.loginfo(cmd)

 



