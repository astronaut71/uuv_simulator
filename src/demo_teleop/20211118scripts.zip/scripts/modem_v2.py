#!/usr/bin/env python

import rospy
from std_msgs.msg import Int16


pub = rospy.Publisher('from_modem', Int16, queue_size=1)

def delay(data):
    rospy.sleep(0.86)
    pub.publish(data)
    rospy.loginfo(data)

def listen():
    rospy.init_node('modem_v2')
    rospy.Subscriber("to_modem", Int16, delay)
    rospy.spin()

if __name__ == '__main__':
    
    listen()
