#!/usr/bin/env python


import rospy

from uuv_gazebo_ros_plugins_msgs.msg import FloatStamped
from sensor_msgs.msg import Joy

pub_motor0 = rospy.Publisher ('/minion/thrusters/0/input', FloatStamped, queue_size=2)
pub_motor1 = rospy.Publisher ('/minion/thrusters/1/input', FloatStamped, queue_size=2)


def send_cmd(j):

    m1data = -j.buttons[1]*100
    m0data = -j.buttons[3]*100

    m0 = FloatStamped()
    m0.header.stamp = rospy.Time.now()
    m0.header.frame_id = 'trash' # change with motor 0
    m0.data = m0data
    pub_motor0.publish(m0)

    m1 = FloatStamped()
    m1.header.stamp = rospy.Time.now()
    m1.header.frame_id = 'trash' # change with motor 0
    m1.data = m1data
    pub_motor1.publish(m1)


def read_joy():
    rospy.init_node('button_full_throttle')
    rospy.Subscriber("/joy", Joy, send_cmd)
    rospy.spin()

if __name__ == '__main__':


    read_joy()



 



